/*===---- riscv_packed_simd.h - RISC-V P intrinsics ------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __RISCV_PACKED_SIMD_H
#define __RISCV_PACKED_SIMD_H

#include <stdint.h>

#if defined(__cplusplus)
extern "C" {
#endif

/* Packed SIMD Types */

typedef int8_t int8x4_t __attribute__((__vector_size__(4)));
typedef uint8_t uint8x4_t __attribute__((__vector_size__(4)));
typedef int16_t int16x2_t __attribute__((__vector_size__(4)));
typedef uint16_t uint16x2_t __attribute__((__vector_size__(4)));

typedef int8_t int8x8_t __attribute__((__vector_size__(8)));
typedef uint8_t uint8x8_t __attribute__((__vector_size__(8)));
typedef int16_t int16x4_t __attribute__((__vector_size__(8)));
typedef uint16_t uint16x4_t __attribute__((__vector_size__(8)));
typedef int32_t int32x2_t __attribute__((__vector_size__(8)));
typedef uint32_t uint32x2_t __attribute__((__vector_size__(8)));

#define __DEFAULT_FN_ATTRS __attribute__((__always_inline__, __nodebug__))

#define __packed_splat2(ty, x) ((ty){(x), (x)})
#define __packed_splat4(ty, x) ((ty){(x), (x), (x), (x)})
#define __packed_splat8(ty, x) ((ty){(x), (x), (x), (x), (x), (x), (x), (x)})

#define __packed_splat(name, ty, scalar_ty, splat)                             \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(scalar_ty __x) {      \
    return splat(ty, __x);                                                     \
  }

#define __packed_shift(name, ty, op, mask)                                     \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,             \
                                                         unsigned __rs2) {     \
    return __rs1 op(__rs2 & (mask));                                           \
  }
#define __packed_shift8(name, ty, op) __packed_shift(name, ty, op, 0x7)
#define __packed_shift16(name, ty, op) __packed_shift(name, ty, op, 0xf)
#define __packed_shift32(name, ty, op) __packed_shift(name, ty, op, 0x1f)

#define __packed_scalar_binary_op(name, ty, scalar_ty, op, splat)              \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,             \
                                                         scalar_ty __rs2) {    \
    return __rs1 op splat(ty, __rs2);                                          \
  }

#define __packed_binary_op(name, ty, op)                                       \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return __rs1 op __rs2;                                                     \
  }

#define __packed_unary_op(name, ty, op)                                        \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {           \
    return op __rs1;                                                           \
  }

#define __packed_binary_builtin(name, ty, builtin)                             \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return builtin(__rs1, __rs2);                                              \
  }

#define __packed_binary_builtin_mixed(name, rty, ty1, ty2, builtin)            \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty1 __rs1,           \
                                                          ty2 __rs2) {         \
    return builtin(__rs1, __rs2);                                              \
  }

#define __packed_ternary_builtin(name, ty, builtin)                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rd, ty __rs1,    \
                                                         ty __rs2) {           \
    return builtin(__rd, __rs1, __rs2);                                        \
  }

#define __packed_ternary_builtin_mixed(name, rty, ty1, ty2, builtin)           \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(rty __rd, ty1 __rs1, \
                                                          ty2 __rs2) {         \
    return builtin(__rd, __rs1, __rs2);                                        \
  }

#define __packed_sh1add(name, ty)                                              \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return (__rs1 << 1) + __rs2;                                               \
  }

/* TODO: switch to sadd_sat(__builtin_elementwise_shl_sat(a, 1), b) once a
 * generic elementwise shl_sat builtin exists. sadd_sat(a, a) is equivalent
 * for signed types and the backend's saturating_shl1 PatFrags matches both
 * shapes. */
#define __packed_sh1sadd(name, ty)                                             \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return __builtin_elementwise_add_sat(                                      \
        __builtin_elementwise_add_sat(__rs1, __rs1), __rs2);                   \
  }

#define __packed_cmp(name, ty, rty, op)                                        \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return (rty)(__rs1 op __rs2);                                              \
  }

#define __packed_pabs(name, ty, rty)                                           \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return (rty)__builtin_elementwise_abs(__rs1);                              \
  }

#define __packed_binary_builtin_cast(name, ty, rty, builtin)                   \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return (rty)builtin(__rs1, __rs2);                                         \
  }

#define __packed_reduction(name, rty, ty, builtin)                             \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          rty __rs2) {         \
    return builtin(__rs1, __rs2);                                              \
  }

#define __packed_merge_builtin(name, ty, mask_ty, builtin)                     \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2,   \
                                                         mask_ty __rd) {       \
    return (ty)builtin(__rs1, __rs2, __rd);                                    \
  }

#define __packed_unary_builtin(name, ty, builtin)                              \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {           \
    return builtin(__rs1);                                                     \
  }

#define __packed_widen_convert(name, rty, ty)                                  \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return __builtin_convertvector(__rs1, rty);                                \
  }
#define __packed_widen_binary_op(name, rty, ty, op)                            \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return __builtin_convertvector(__rs1, rty)                                 \
        op __builtin_convertvector(__rs2, rty);                                \
  }
#define __packed_widen_mul(name, rty, ty)                                      \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return __builtin_convertvector(__rs1, rty) *                               \
           __builtin_convertvector(__rs2, rty);                                \
  }
#define __packed_widen_mulsu(name, rty, ty1, ty2, uty)                         \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty1 __rs1,           \
                                                          ty2 __rs2) {         \
    return __builtin_convertvector(__rs1, rty) *                               \
           (rty) __builtin_convertvector(__rs2, uty);                          \
  }
#define __packed_widen_high2(name, rty, ty)                                    \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return (rty)__builtin_shufflevector((ty){0}, __rs1, 0, 2, 1, 3);           \
  }
#define __packed_widen_high4(name, rty, ty)                                    \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return (rty)__builtin_shufflevector((ty){0}, __rs1, 0, 4, 1, 5, 2, 6, 3,   \
                                        7);                                    \
  }

#define __packed_narrow_even2(name, rty, ty, sty)                              \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return __builtin_convertvector(__rs1, rty);                                \
  }
#define __packed_narrow_even4(name, rty, ty, sty)                              \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return __builtin_convertvector(__rs1, rty);                                \
  }
#define __packed_narrow_odd2(name, rty, ty, sty, uty)                          \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return __builtin_shufflevector((sty)__rs1, (sty)__rs1, 1, 3);              \
  }
#define __packed_narrow_odd4(name, rty, ty, sty, uty)                          \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return __builtin_shufflevector((sty)__rs1, (sty)__rs1, 1, 3, 5, 7);        \
  }

/* Packed Reverse: reverse the order of the elements. Lowered to a single
 * rev8/rev16/ppairoe.* by the backend's packed reverse-shuffle handling. */
#define __packed_reverse2(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {           \
    return __builtin_shufflevector(__rs1, __rs1, 1, 0);                        \
  }
#define __packed_reverse4(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {           \
    return __builtin_shufflevector(__rs1, __rs1, 3, 2, 1, 0);                  \
  }
#define __packed_reverse8(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {           \
    return __builtin_shufflevector(__rs1, __rs1, 7, 6, 5, 4, 3, 2, 1, 0);      \
  }

#define __packed_zip2(name, rty, ty)                                           \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return __builtin_shufflevector(__rs1, __rs2, 0, 2, 1, 3);                  \
  }
#define __packed_zip4(name, rty, ty)                                           \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return __builtin_shufflevector(__rs1, __rs2, 0, 4, 1, 5, 2, 6, 3, 7);      \
  }
#define __packed_unzipe2(name, rty, ty)                                        \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return __builtin_shufflevector(__rs1, __rs1, 0, 2);                        \
  }
#define __packed_unzipe4(name, rty, ty)                                        \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return __builtin_shufflevector(__rs1, __rs1, 0, 2, 4, 6);                  \
  }
#define __packed_unzipo2(name, rty, ty)                                        \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return __builtin_shufflevector(__rs1, __rs1, 1, 3);                        \
  }
#define __packed_unzipo4(name, rty, ty)                                        \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1) {          \
    return __builtin_shufflevector(__rs1, __rs1, 1, 3, 5, 7);                  \
  }

#define __packed_pair_ee4(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return __builtin_shufflevector(__rs1, __rs2, 0, 4, 2, 6);                  \
  }
#define __packed_pair_eo4(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return __builtin_shufflevector(__rs1, __rs2, 0, 5, 2, 7);                  \
  }
#define __packed_pair_oe4(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return __builtin_shufflevector(__rs1, __rs2, 1, 4, 3, 6);                  \
  }
#define __packed_pair_oo4(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return __builtin_shufflevector(__rs1, __rs2, 1, 5, 3, 7);                  \
  }
#define __packed_pair_ee8(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return __builtin_shufflevector(__rs1, __rs2, 0, 8, 2, 10, 4, 12, 6, 14);   \
  }
#define __packed_pair_eo8(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return __builtin_shufflevector(__rs1, __rs2, 0, 9, 2, 11, 4, 13, 6, 15);   \
  }
#define __packed_pair_oe8(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return __builtin_shufflevector(__rs1, __rs2, 1, 8, 3, 10, 5, 12, 7, 14);   \
  }
#define __packed_pair_oo8(name, ty)                                            \
  static __inline__ ty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1, ty __rs2) { \
    return __builtin_shufflevector(__rs1, __rs2, 1, 9, 3, 11, 5, 13, 7, 15);   \
  }

#define __packed_nzip2(name, rty, ty)                                          \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return __builtin_shufflevector((rty)__rs1, (rty)__rs2, 0, 4, 2, 6);        \
  }
#define __packed_nzip4(name, rty, ty)                                          \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return __builtin_shufflevector((rty)__rs1, (rty)__rs2, 0, 8, 2, 10, 4, 12, \
                                   6, 14);                                     \
  }
#define __packed_nziph2(name, rty, ty)                                         \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return __builtin_shufflevector((rty)__rs1, (rty)__rs2, 1, 5, 3, 7);        \
  }
#define __packed_nziph4(name, rty, ty)                                         \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return __builtin_shufflevector((rty)__rs1, (rty)__rs2, 1, 9, 3, 11, 5, 13, \
                                   7, 15);                                     \
  }

#define __packed_abdsum(name, rty, ty, builtin)                                \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(ty __rs1,            \
                                                          ty __rs2) {          \
    return builtin(__rs1, __rs2);                                              \
  }

#define __packed_ternary_builtin_cast(name, rty, ty, builtin)                  \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_##name(rty __rd, ty __rs1,  \
                                                          ty __rs2) {          \
    return builtin(__rd, __rs1, __rs2);                                        \
  }

#define __packed_reinterpret(name, rty, ty)                                    \
  static __inline__ rty __DEFAULT_FN_ATTRS __riscv_preinterpret_##name(        \
      ty __x) {                                                                \
    return __builtin_bit_cast(rty, __x);                                       \
  }

// clang-format off: macro call sites have no trailing semicolons, which
// confuses clang-format into a deeply nested expression.

/* Packed Splat (32-bit) */
__packed_splat(pmv_s_u8x4, uint8x4_t, uint8_t, __packed_splat4)
__packed_splat(pmv_s_i8x4, int8x4_t, int8_t, __packed_splat4)
__packed_splat(pmv_s_u16x2, uint16x2_t, uint16_t, __packed_splat2)
__packed_splat(pmv_s_i16x2, int16x2_t, int16_t, __packed_splat2)

/* Packed Splat (64-bit) */
__packed_splat(pmv_s_u8x8, uint8x8_t, uint8_t, __packed_splat8)
__packed_splat(pmv_s_i8x8, int8x8_t, int8_t, __packed_splat8)
__packed_splat(pmv_s_u16x4, uint16x4_t, uint16_t, __packed_splat4)
__packed_splat(pmv_s_i16x4, int16x4_t, int16_t, __packed_splat4)
__packed_splat(pmv_s_u32x2, uint32x2_t, uint32_t, __packed_splat2)
__packed_splat(pmv_s_i32x2, int32x2_t, int32_t, __packed_splat2)

/* Packed Addition and Subtraction (32-bit) */
__packed_binary_op(padd_i8x4, int8x4_t, +)
__packed_binary_op(padd_u8x4, uint8x4_t, +)
__packed_binary_op(padd_i16x2, int16x2_t, +)
__packed_binary_op(padd_u16x2, uint16x2_t, +)
__packed_binary_op(psub_i8x4, int8x4_t, -)
__packed_binary_op(psub_u8x4, uint8x4_t, -)
__packed_binary_op(psub_i16x2, int16x2_t, -)
__packed_binary_op(psub_u16x2, uint16x2_t, -)
__packed_unary_op(pneg_i8x4, int8x4_t, -)
__packed_unary_op(pneg_i16x2, int16x2_t, -)

/* Packed Addition and Subtraction (64-bit) */
__packed_binary_op(padd_i8x8, int8x8_t, +)
__packed_binary_op(padd_u8x8, uint8x8_t, +)
__packed_binary_op(padd_i16x4, int16x4_t, +)
__packed_binary_op(padd_u16x4, uint16x4_t, +)
__packed_binary_op(padd_i32x2, int32x2_t, +)
__packed_binary_op(padd_u32x2, uint32x2_t, +)
__packed_binary_op(psub_i8x8, int8x8_t, -)
__packed_binary_op(psub_u8x8, uint8x8_t, -)
__packed_binary_op(psub_i16x4, int16x4_t, -)
__packed_binary_op(psub_u16x4, uint16x4_t, -)
__packed_binary_op(psub_i32x2, int32x2_t, -)
__packed_binary_op(psub_u32x2, uint32x2_t, -)
__packed_unary_op(pneg_i8x8, int8x8_t, -)
__packed_unary_op(pneg_i16x4, int16x4_t, -)
__packed_unary_op(pneg_i32x2, int32x2_t, -)

/* Packed Addition with Scalar (32-bit) */
__packed_scalar_binary_op(padd_s_u8x4, uint8x4_t, uint8_t, +, __packed_splat4)
__packed_scalar_binary_op(padd_s_i8x4, int8x4_t, int8_t, +, __packed_splat4)
__packed_scalar_binary_op(padd_s_u16x2, uint16x2_t, uint16_t, +,
                          __packed_splat2)
__packed_scalar_binary_op(padd_s_i16x2, int16x2_t, int16_t, +,
                          __packed_splat2)

/* Packed Addition with Scalar (64-bit) */
__packed_scalar_binary_op(padd_s_u8x8, uint8x8_t, uint8_t, +, __packed_splat8)
__packed_scalar_binary_op(padd_s_i8x8, int8x8_t, int8_t, +, __packed_splat8)
__packed_scalar_binary_op(padd_s_u16x4, uint16x4_t, uint16_t, +,
                          __packed_splat4)
__packed_scalar_binary_op(padd_s_i16x4, int16x4_t, int16_t, +,
                          __packed_splat4)
__packed_scalar_binary_op(padd_s_u32x2, uint32x2_t, uint32_t, +,
                          __packed_splat2)
__packed_scalar_binary_op(padd_s_i32x2, int32x2_t, int32_t, +,
                          __packed_splat2)

/* Packed Saturating Addition and Subtraction (32-bit) */
__packed_binary_builtin(psadd_i8x4, int8x4_t, __builtin_elementwise_add_sat)
__packed_binary_builtin(psadd_i16x2, int16x2_t, __builtin_elementwise_add_sat)
__packed_binary_builtin(psaddu_u8x4, uint8x4_t, __builtin_elementwise_add_sat)
__packed_binary_builtin(psaddu_u16x2, uint16x2_t, __builtin_elementwise_add_sat)
__packed_binary_builtin(pssub_i8x4, int8x4_t, __builtin_elementwise_sub_sat)
__packed_binary_builtin(pssub_i16x2, int16x2_t, __builtin_elementwise_sub_sat)
__packed_binary_builtin(pssubu_u8x4, uint8x4_t, __builtin_elementwise_sub_sat)
__packed_binary_builtin(pssubu_u16x2, uint16x2_t, __builtin_elementwise_sub_sat)

/* Packed Saturating Addition and Subtraction (64-bit) */
__packed_binary_builtin(psadd_i8x8, int8x8_t, __builtin_elementwise_add_sat)
__packed_binary_builtin(psadd_i16x4, int16x4_t, __builtin_elementwise_add_sat)
__packed_binary_builtin(psadd_i32x2, int32x2_t, __builtin_elementwise_add_sat)
__packed_binary_builtin(psaddu_u8x8, uint8x8_t, __builtin_elementwise_add_sat)
__packed_binary_builtin(psaddu_u16x4, uint16x4_t, __builtin_elementwise_add_sat)
__packed_binary_builtin(psaddu_u32x2, uint32x2_t, __builtin_elementwise_add_sat)
__packed_binary_builtin(pssub_i8x8, int8x8_t, __builtin_elementwise_sub_sat)
__packed_binary_builtin(pssub_i16x4, int16x4_t, __builtin_elementwise_sub_sat)
__packed_binary_builtin(pssub_i32x2, int32x2_t, __builtin_elementwise_sub_sat)
__packed_binary_builtin(pssubu_u8x8, uint8x8_t, __builtin_elementwise_sub_sat)
__packed_binary_builtin(pssubu_u16x4, uint16x4_t, __builtin_elementwise_sub_sat)
__packed_binary_builtin(pssubu_u32x2, uint32x2_t, __builtin_elementwise_sub_sat)

/* Packed Shift-Add (32-bit) */
__packed_sh1add(psh1add_i16x2, int16x2_t)
__packed_sh1add(psh1add_u16x2, uint16x2_t)
__packed_sh1sadd(pssh1sadd_i16x2, int16x2_t)

/* Packed Shift-Add (64-bit) */
__packed_sh1add(psh1add_i16x4, int16x4_t)
__packed_sh1add(psh1add_u16x4, uint16x4_t)
__packed_sh1add(psh1add_i32x2, int32x2_t)
__packed_sh1add(psh1add_u32x2, uint32x2_t)
__packed_sh1sadd(pssh1sadd_i16x4, int16x4_t)
__packed_sh1sadd(pssh1sadd_i32x2, int32x2_t)

/* Packed Exchanged Addition and Subtraction (32-bit) */
__packed_binary_builtin(pas_x_i16x2, int16x2_t, __builtin_riscv_pas_x_i16x2)
__packed_binary_builtin(psa_x_i16x2, int16x2_t, __builtin_riscv_psa_x_i16x2)
__packed_binary_builtin(psas_x_i16x2, int16x2_t, __builtin_riscv_psas_x_i16x2)
__packed_binary_builtin(pssa_x_i16x2, int16x2_t, __builtin_riscv_pssa_x_i16x2)
__packed_binary_builtin(paas_x_i16x2, int16x2_t, __builtin_riscv_paas_x_i16x2)
__packed_binary_builtin(pasa_x_i16x2, int16x2_t, __builtin_riscv_pasa_x_i16x2)

/* Packed Exchanged Addition and Subtraction (64-bit) */
__packed_binary_builtin(pas_x_i16x4, int16x4_t, __builtin_riscv_pas_x_i16x4)
__packed_binary_builtin(psa_x_i16x4, int16x4_t, __builtin_riscv_psa_x_i16x4)
__packed_binary_builtin(psas_x_i16x4, int16x4_t, __builtin_riscv_psas_x_i16x4)
__packed_binary_builtin(pssa_x_i16x4, int16x4_t, __builtin_riscv_pssa_x_i16x4)
__packed_binary_builtin(paas_x_i16x4, int16x4_t, __builtin_riscv_paas_x_i16x4)
__packed_binary_builtin(pasa_x_i16x4, int16x4_t, __builtin_riscv_pasa_x_i16x4)
__packed_binary_builtin(pas_x_i32x2, int32x2_t, __builtin_riscv_pas_x_i32x2)
__packed_binary_builtin(psa_x_i32x2, int32x2_t, __builtin_riscv_psa_x_i32x2)
__packed_binary_builtin(psas_x_i32x2, int32x2_t, __builtin_riscv_psas_x_i32x2)
__packed_binary_builtin(pssa_x_i32x2, int32x2_t, __builtin_riscv_pssa_x_i32x2)
__packed_binary_builtin(paas_x_i32x2, int32x2_t, __builtin_riscv_paas_x_i32x2)
__packed_binary_builtin(pasa_x_i32x2, int32x2_t, __builtin_riscv_pasa_x_i32x2)

/* Packed Minimum and Maximum (32-bit) */
__packed_binary_builtin(pmin_i8x4, int8x4_t, __builtin_elementwise_min)
__packed_binary_builtin(pmin_i16x2, int16x2_t, __builtin_elementwise_min)
__packed_binary_builtin(pminu_u8x4, uint8x4_t, __builtin_elementwise_min)
__packed_binary_builtin(pminu_u16x2, uint16x2_t, __builtin_elementwise_min)
__packed_binary_builtin(pmax_i8x4, int8x4_t, __builtin_elementwise_max)
__packed_binary_builtin(pmax_i16x2, int16x2_t, __builtin_elementwise_max)
__packed_binary_builtin(pmaxu_u8x4, uint8x4_t, __builtin_elementwise_max)
__packed_binary_builtin(pmaxu_u16x2, uint16x2_t, __builtin_elementwise_max)

/* Packed Minimum and Maximum (64-bit) */
__packed_binary_builtin(pmin_i8x8, int8x8_t, __builtin_elementwise_min)
__packed_binary_builtin(pmin_i16x4, int16x4_t, __builtin_elementwise_min)
__packed_binary_builtin(pmin_i32x2, int32x2_t, __builtin_elementwise_min)
__packed_binary_builtin(pminu_u8x8, uint8x8_t, __builtin_elementwise_min)
__packed_binary_builtin(pminu_u16x4, uint16x4_t, __builtin_elementwise_min)
__packed_binary_builtin(pminu_u32x2, uint32x2_t, __builtin_elementwise_min)
__packed_binary_builtin(pmax_i8x8, int8x8_t, __builtin_elementwise_max)
__packed_binary_builtin(pmax_i16x4, int16x4_t, __builtin_elementwise_max)
__packed_binary_builtin(pmax_i32x2, int32x2_t, __builtin_elementwise_max)
__packed_binary_builtin(pmaxu_u8x8, uint8x8_t, __builtin_elementwise_max)
__packed_binary_builtin(pmaxu_u16x4, uint16x4_t, __builtin_elementwise_max)
__packed_binary_builtin(pmaxu_u32x2, uint32x2_t, __builtin_elementwise_max)

/* Packed Comparison (32-bit) */
__packed_cmp(pmseq_i8x4_u8x4, int8x4_t, uint8x4_t, ==)
__packed_cmp(pmseq_u8x4_u8x4, uint8x4_t, uint8x4_t, ==)
__packed_cmp(pmsne_i8x4_u8x4, int8x4_t, uint8x4_t, !=)
__packed_cmp(pmsne_u8x4_u8x4, uint8x4_t, uint8x4_t, !=)
__packed_cmp(pmslt_u8x4, int8x4_t, uint8x4_t, <)
__packed_cmp(pmsltu_u8x4, uint8x4_t, uint8x4_t, <)
__packed_cmp(pmsgt_u8x4, int8x4_t, uint8x4_t, >)
__packed_cmp(pmsgtu_u8x4, uint8x4_t, uint8x4_t, >)
__packed_cmp(pmsge_u8x4, int8x4_t, uint8x4_t, >=)
__packed_cmp(pmsgeu_u8x4, uint8x4_t, uint8x4_t, >=)
__packed_cmp(pmsle_u8x4, int8x4_t, uint8x4_t, <=)
__packed_cmp(pmsleu_u8x4, uint8x4_t, uint8x4_t, <=)
__packed_cmp(pmseq_i16x2_u16x2, int16x2_t, uint16x2_t, ==)
__packed_cmp(pmseq_u16x2_u16x2, uint16x2_t, uint16x2_t, ==)
__packed_cmp(pmsne_i16x2_u16x2, int16x2_t, uint16x2_t, !=)
__packed_cmp(pmsne_u16x2_u16x2, uint16x2_t, uint16x2_t, !=)
__packed_cmp(pmslt_u16x2, int16x2_t, uint16x2_t, <)
__packed_cmp(pmsltu_u16x2, uint16x2_t, uint16x2_t, <)
__packed_cmp(pmsgt_u16x2, int16x2_t, uint16x2_t, >)
__packed_cmp(pmsgtu_u16x2, uint16x2_t, uint16x2_t, >)
__packed_cmp(pmsge_u16x2, int16x2_t, uint16x2_t, >=)
__packed_cmp(pmsgeu_u16x2, uint16x2_t, uint16x2_t, >=)
__packed_cmp(pmsle_u16x2, int16x2_t, uint16x2_t, <=)
__packed_cmp(pmsleu_u16x2, uint16x2_t, uint16x2_t, <=)

/* Packed Comparison (64-bit) */
__packed_cmp(pmseq_i8x8_u8x8, int8x8_t, uint8x8_t, ==)
__packed_cmp(pmseq_u8x8_u8x8, uint8x8_t, uint8x8_t, ==)
__packed_cmp(pmsne_i8x8_u8x8, int8x8_t, uint8x8_t, !=)
__packed_cmp(pmsne_u8x8_u8x8, uint8x8_t, uint8x8_t, !=)
__packed_cmp(pmslt_u8x8, int8x8_t, uint8x8_t, <)
__packed_cmp(pmsltu_u8x8, uint8x8_t, uint8x8_t, <)
__packed_cmp(pmsgt_u8x8, int8x8_t, uint8x8_t, >)
__packed_cmp(pmsgtu_u8x8, uint8x8_t, uint8x8_t, >)
__packed_cmp(pmsge_u8x8, int8x8_t, uint8x8_t, >=)
__packed_cmp(pmsgeu_u8x8, uint8x8_t, uint8x8_t, >=)
__packed_cmp(pmsle_u8x8, int8x8_t, uint8x8_t, <=)
__packed_cmp(pmsleu_u8x8, uint8x8_t, uint8x8_t, <=)
__packed_cmp(pmseq_i16x4_u16x4, int16x4_t, uint16x4_t, ==)
__packed_cmp(pmseq_u16x4_u16x4, uint16x4_t, uint16x4_t, ==)
__packed_cmp(pmsne_i16x4_u16x4, int16x4_t, uint16x4_t, !=)
__packed_cmp(pmsne_u16x4_u16x4, uint16x4_t, uint16x4_t, !=)
__packed_cmp(pmslt_u16x4, int16x4_t, uint16x4_t, <)
__packed_cmp(pmsltu_u16x4, uint16x4_t, uint16x4_t, <)
__packed_cmp(pmsgt_u16x4, int16x4_t, uint16x4_t, >)
__packed_cmp(pmsgtu_u16x4, uint16x4_t, uint16x4_t, >)
__packed_cmp(pmsge_u16x4, int16x4_t, uint16x4_t, >=)
__packed_cmp(pmsgeu_u16x4, uint16x4_t, uint16x4_t, >=)
__packed_cmp(pmsle_u16x4, int16x4_t, uint16x4_t, <=)
__packed_cmp(pmsleu_u16x4, uint16x4_t, uint16x4_t, <=)
__packed_cmp(pmseq_i32x2_u32x2, int32x2_t, uint32x2_t, ==)
__packed_cmp(pmseq_u32x2_u32x2, uint32x2_t, uint32x2_t, ==)
__packed_cmp(pmsne_i32x2_u32x2, int32x2_t, uint32x2_t, !=)
__packed_cmp(pmsne_u32x2_u32x2, uint32x2_t, uint32x2_t, !=)
__packed_cmp(pmslt_u32x2, int32x2_t, uint32x2_t, <)
__packed_cmp(pmsltu_u32x2, uint32x2_t, uint32x2_t, <)
__packed_cmp(pmsgt_u32x2, int32x2_t, uint32x2_t, >)
__packed_cmp(pmsgtu_u32x2, uint32x2_t, uint32x2_t, >)
__packed_cmp(pmsge_u32x2, int32x2_t, uint32x2_t, >=)
__packed_cmp(pmsgeu_u32x2, uint32x2_t, uint32x2_t, >=)
__packed_cmp(pmsle_u32x2, int32x2_t, uint32x2_t, <=)
__packed_cmp(pmsleu_u32x2, uint32x2_t, uint32x2_t, <=)

/* Packed Shifts (32-bit) */
__packed_shift8(psll_s_u8x4, uint8x4_t, <<)
__packed_shift8(psll_s_i8x4, int8x4_t, <<)
__packed_shift16(psll_s_u16x2, uint16x2_t, <<)
__packed_shift16(psll_s_i16x2, int16x2_t, <<)
__packed_shift8(psrl_s_u8x4, uint8x4_t, >>)
__packed_shift16(psrl_s_u16x2, uint16x2_t, >>)
__packed_shift8(psra_s_i8x4, int8x4_t, >>)
__packed_shift16(psra_s_i16x2, int16x2_t, >>)

/* Packed Shifts (64-bit) */
__packed_shift8(psll_s_u8x8, uint8x8_t, <<)
__packed_shift8(psll_s_i8x8, int8x8_t, <<)
__packed_shift16(psll_s_u16x4, uint16x4_t, <<)
__packed_shift16(psll_s_i16x4, int16x4_t, <<)
__packed_shift32(psll_s_u32x2, uint32x2_t, <<)
__packed_shift32(psll_s_i32x2, int32x2_t, <<)
__packed_shift8(psrl_s_u8x8, uint8x8_t, >>)
__packed_shift16(psrl_s_u16x4, uint16x4_t, >>)
__packed_shift32(psrl_s_u32x2, uint32x2_t, >>)
__packed_shift8(psra_s_i8x8, int8x8_t, >>)
__packed_shift16(psra_s_i16x4, int16x4_t, >>)
__packed_shift32(psra_s_i32x2, int32x2_t, >>)

/* Packed Saturating and Rounding Shifts (32-bit) */
__packed_binary_builtin_mixed(pssha_s_i16x2, int16x2_t, int16x2_t, int, __builtin_riscv_pssha_s_i16x2)
__packed_binary_builtin_mixed(psshar_s_i16x2, int16x2_t, int16x2_t, int, __builtin_riscv_psshar_s_i16x2)
__packed_binary_builtin_mixed(psshl_s_u16x2, uint16x2_t, uint16x2_t, int, __builtin_riscv_psshl_s_u16x2)
__packed_binary_builtin_mixed(psshlr_s_u16x2, uint16x2_t, uint16x2_t, int, __builtin_riscv_psshlr_s_u16x2)

/* Packed Saturating and Rounding Shifts (64-bit) */
__packed_binary_builtin_mixed(pssha_s_i16x4, int16x4_t, int16x4_t, int, __builtin_riscv_pssha_s_i16x4)
__packed_binary_builtin_mixed(pssha_s_i32x2, int32x2_t, int32x2_t, int, __builtin_riscv_pssha_s_i32x2)
__packed_binary_builtin_mixed(psshar_s_i16x4, int16x4_t, int16x4_t, int, __builtin_riscv_psshar_s_i16x4)
__packed_binary_builtin_mixed(psshar_s_i32x2, int32x2_t, int32x2_t, int, __builtin_riscv_psshar_s_i32x2)
__packed_binary_builtin_mixed(psshl_s_u16x4, uint16x4_t, uint16x4_t, int, __builtin_riscv_psshl_s_u16x4)
__packed_binary_builtin_mixed(psshl_s_u32x2, uint32x2_t, uint32x2_t, int, __builtin_riscv_psshl_s_u32x2)
__packed_binary_builtin_mixed(psshlr_s_u16x4, uint16x4_t, uint16x4_t, int, __builtin_riscv_psshlr_s_u16x4)
__packed_binary_builtin_mixed(psshlr_s_u32x2, uint32x2_t, uint32x2_t, int, __builtin_riscv_psshlr_s_u32x2)

/* Packed Logical Operations (32-bit) */
__packed_binary_op(pand_i8x4, int8x4_t, &)
__packed_binary_op(pand_u8x4, uint8x4_t, &)
__packed_binary_op(pand_i16x2, int16x2_t, &)
__packed_binary_op(pand_u16x2, uint16x2_t, &)
__packed_binary_op(por_i8x4, int8x4_t, |)
__packed_binary_op(por_u8x4, uint8x4_t, |)
__packed_binary_op(por_i16x2, int16x2_t, |)
__packed_binary_op(por_u16x2, uint16x2_t, |)
__packed_binary_op(pxor_i8x4, int8x4_t, ^)
__packed_binary_op(pxor_u8x4, uint8x4_t, ^)
__packed_binary_op(pxor_i16x2, int16x2_t, ^)
__packed_binary_op(pxor_u16x2, uint16x2_t, ^)
__packed_unary_op(pnot_i8x4, int8x4_t, ~)
__packed_unary_op(pnot_u8x4, uint8x4_t, ~)
__packed_unary_op(pnot_i16x2, int16x2_t, ~)
__packed_unary_op(pnot_u16x2, uint16x2_t, ~)

/* Packed Logical Operations (64-bit) */
__packed_binary_op(pand_i8x8, int8x8_t, &)
__packed_binary_op(pand_u8x8, uint8x8_t, &)
__packed_binary_op(pand_i16x4, int16x4_t, &)
__packed_binary_op(pand_u16x4, uint16x4_t, &)
__packed_binary_op(pand_i32x2, int32x2_t, &)
__packed_binary_op(pand_u32x2, uint32x2_t, &)
__packed_binary_op(por_i8x8, int8x8_t, |)
__packed_binary_op(por_u8x8, uint8x8_t, |)
__packed_binary_op(por_i16x4, int16x4_t, |)
__packed_binary_op(por_u16x4, uint16x4_t, |)
__packed_binary_op(por_i32x2, int32x2_t, |)
__packed_binary_op(por_u32x2, uint32x2_t, |)
__packed_binary_op(pxor_i8x8, int8x8_t, ^)
__packed_binary_op(pxor_u8x8, uint8x8_t, ^)
__packed_binary_op(pxor_i16x4, int16x4_t, ^)
__packed_binary_op(pxor_u16x4, uint16x4_t, ^)
__packed_binary_op(pxor_i32x2, int32x2_t, ^)
__packed_binary_op(pxor_u32x2, uint32x2_t, ^)
__packed_unary_op(pnot_i8x8, int8x8_t, ~)
__packed_unary_op(pnot_u8x8, uint8x8_t, ~)
__packed_unary_op(pnot_i16x4, int16x4_t, ~)
__packed_unary_op(pnot_u16x4, uint16x4_t, ~)
__packed_unary_op(pnot_i32x2, int32x2_t, ~)
__packed_unary_op(pnot_u32x2, uint32x2_t, ~)

/* Packed Widening Convert */
__packed_widen_convert(pwcvt_i16x4, int16x4_t, int8x4_t)
__packed_widen_convert(pwcvt_i32x2, int32x2_t, int16x2_t)
__packed_widen_convert(pwcvtu_u16x4, uint16x4_t, uint8x4_t)
__packed_widen_convert(pwcvtu_u32x2, uint32x2_t, uint16x2_t)
__packed_widen_high4(pwcvth_i16x4, int16x4_t, int8x4_t)
__packed_widen_high4(pwcvth_u16x4, uint16x4_t, uint8x4_t)
__packed_widen_high2(pwcvth_i32x2, int32x2_t, int16x2_t)
__packed_widen_high2(pwcvth_u32x2, uint32x2_t, uint16x2_t)

/* Packed Widening Addition and Subtraction */
__packed_widen_binary_op(pwadd_i16x4, int16x4_t, int8x4_t, +)
__packed_widen_binary_op(pwadd_i32x2, int32x2_t, int16x2_t, +)
__packed_widen_binary_op(pwaddu_u16x4, uint16x4_t, uint8x4_t, +)
__packed_widen_binary_op(pwaddu_u32x2, uint32x2_t, uint16x2_t, +)
__packed_widen_binary_op(pwsub_i16x4, int16x4_t, int8x4_t, -)
__packed_widen_binary_op(pwsub_i32x2, int32x2_t, int16x2_t, -)
__packed_widen_binary_op(pwsubu_u16x4, uint16x4_t, uint8x4_t, -)
__packed_widen_binary_op(pwsubu_u32x2, uint32x2_t, uint16x2_t, -)

/* Packed Widening Multiply (32-bit) */
__packed_widen_mul(pwmul_i16x4, int16x4_t, int8x4_t)
__packed_widen_mul(pwmul_i32x2, int32x2_t, int16x2_t)
__packed_widen_mul(pwmulu_u16x4, uint16x4_t, uint8x4_t)
__packed_widen_mul(pwmulu_u32x2, uint32x2_t, uint16x2_t)
__packed_widen_mulsu(pwmulsu_i16x4, int16x4_t, int8x4_t, uint8x4_t, uint16x4_t)
__packed_widen_mulsu(pwmulsu_i32x2, int32x2_t, int16x2_t, uint16x2_t,
                     uint32x2_t)

/* Packed Narrowing Convert */
__packed_narrow_even4(pncvt_i8x4, int8x4_t, int16x4_t, int8x8_t)
__packed_narrow_even4(pncvt_u8x4, uint8x4_t, uint16x4_t, uint8x8_t)
__packed_narrow_even2(pncvt_i16x2, int16x2_t, int32x2_t, int16x4_t)
__packed_narrow_even2(pncvt_u16x2, uint16x2_t, uint32x2_t, uint16x4_t)
__packed_narrow_odd4(pncvth_i8x4, int8x4_t, int16x4_t, int8x8_t, uint16x4_t)
__packed_narrow_odd4(pncvth_u8x4, uint8x4_t, uint16x4_t, uint8x8_t, uint16x4_t)
__packed_narrow_odd2(pncvth_i16x2, int16x2_t, int32x2_t, int16x4_t, uint32x2_t)
__packed_narrow_odd2(pncvth_u16x2, uint16x2_t, uint32x2_t, uint16x4_t, uint32x2_t)

/* Packed Reverse (32-bit) */
__packed_reverse4(prev_i8x4, int8x4_t)
__packed_reverse4(prev_u8x4, uint8x4_t)
__packed_reverse2(prev_i16x2, int16x2_t)
__packed_reverse2(prev_u16x2, uint16x2_t)

/* Packed Reverse (64-bit) */
__packed_reverse8(prev_i8x8, int8x8_t)
__packed_reverse8(prev_u8x8, uint8x8_t)
__packed_reverse4(prev_i16x4, int16x4_t)
__packed_reverse4(prev_u16x4, uint16x4_t)
__packed_reverse2(prev_i32x2, int32x2_t)
__packed_reverse2(prev_u32x2, uint32x2_t)

/* Packed Zip */
__packed_zip4(pzip_i8x8, int8x8_t, int8x4_t)
__packed_zip4(pzip_u8x8, uint8x8_t, uint8x4_t)
__packed_zip2(pzip_i16x4, int16x4_t, int16x2_t)
__packed_zip2(pzip_u16x4, uint16x4_t, uint16x2_t)

/* Packed Unzip */
__packed_unzipe4(punzipe_i8x4, int8x4_t, int8x8_t)
__packed_unzipo4(punzipo_i8x4, int8x4_t, int8x8_t)
__packed_unzipe4(punzipe_u8x4, uint8x4_t, uint8x8_t)
__packed_unzipo4(punzipo_u8x4, uint8x4_t, uint8x8_t)
__packed_unzipe2(punzipe_i16x2, int16x2_t, int16x4_t)
__packed_unzipo2(punzipo_i16x2, int16x2_t, int16x4_t)
__packed_unzipe2(punzipe_u16x2, uint16x2_t, uint16x4_t)
__packed_unzipo2(punzipo_u16x2, uint16x2_t, uint16x4_t)

/* Packed Pair (32-bit byte forms) */
__packed_pair_ee4(ppaire_i8x4, int8x4_t)
__packed_pair_ee4(ppaire_u8x4, uint8x4_t)
__packed_pair_eo4(ppaireo_i8x4, int8x4_t)
__packed_pair_eo4(ppaireo_u8x4, uint8x4_t)
__packed_pair_oe4(ppairoe_i8x4, int8x4_t)
__packed_pair_oe4(ppairoe_u8x4, uint8x4_t)
__packed_pair_oo4(ppairo_i8x4, int8x4_t)
__packed_pair_oo4(ppairo_u8x4, uint8x4_t)

/* Packed Pair (64-bit byte and halfword forms) */
__packed_pair_ee8(ppaire_i8x8, int8x8_t)
__packed_pair_ee8(ppaire_u8x8, uint8x8_t)
__packed_pair_eo8(ppaireo_i8x8, int8x8_t)
__packed_pair_eo8(ppaireo_u8x8, uint8x8_t)
__packed_pair_oe8(ppairoe_i8x8, int8x8_t)
__packed_pair_oe8(ppairoe_u8x8, uint8x8_t)
__packed_pair_oo8(ppairo_i8x8, int8x8_t)
__packed_pair_oo8(ppairo_u8x8, uint8x8_t)
__packed_pair_ee4(ppaire_i16x4, int16x4_t)
__packed_pair_ee4(ppaire_u16x4, uint16x4_t)
__packed_pair_eo4(ppaireo_i16x4, int16x4_t)
__packed_pair_eo4(ppaireo_u16x4, uint16x4_t)
__packed_pair_oe4(ppairoe_i16x4, int16x4_t)
__packed_pair_oe4(ppairoe_u16x4, uint16x4_t)
__packed_pair_oo4(ppairo_i16x4, int16x4_t)
__packed_pair_oo4(ppairo_u16x4, uint16x4_t)

/* Packed Narrowing Zip (32-bit) */
__packed_nzip2(pnzip_i8x4, int8x4_t, int16x2_t)
__packed_nzip2(pnzip_u8x4, uint8x4_t, uint16x2_t)
__packed_nziph2(pnziph_i8x4, int8x4_t, int16x2_t)
__packed_nziph2(pnziph_u8x4, uint8x4_t, uint16x2_t)

/* Packed Narrowing Zip (64-bit) */
__packed_nzip4(pnzip_i8x8, int8x8_t, int16x4_t)
__packed_nzip4(pnzip_u8x8, uint8x8_t, uint16x4_t)
__packed_nzip2(pnzip_i16x4, int16x4_t, int32x2_t)
__packed_nzip2(pnzip_u16x4, uint16x4_t, uint32x2_t)
__packed_nziph4(pnziph_i8x8, int8x8_t, int16x4_t)
__packed_nziph4(pnziph_u8x8, uint8x8_t, uint16x4_t)
__packed_nziph2(pnziph_i16x4, int16x4_t, int32x2_t)
__packed_nziph2(pnziph_u16x4, uint16x4_t, uint32x2_t)

/* Packed Averaging Addition and Subtraction (32-bit) */
__packed_binary_builtin(paadd_i8x4, int8x4_t, __builtin_riscv_paadd_i8x4)
__packed_binary_builtin(paadd_i16x2, int16x2_t, __builtin_riscv_paadd_i16x2)
__packed_binary_builtin(paaddu_u8x4, uint8x4_t, __builtin_riscv_paaddu_u8x4)
__packed_binary_builtin(paaddu_u16x2, uint16x2_t, __builtin_riscv_paaddu_u16x2)
__packed_binary_builtin(pasub_i8x4, int8x4_t, __builtin_riscv_pasub_i8x4)
__packed_binary_builtin(pasub_i16x2, int16x2_t, __builtin_riscv_pasub_i16x2)
__packed_binary_builtin(pasubu_u8x4, uint8x4_t, __builtin_riscv_pasubu_u8x4)
__packed_binary_builtin(pasubu_u16x2, uint16x2_t, __builtin_riscv_pasubu_u16x2)

/* Packed Averaging Addition and Subtraction (64-bit) */
__packed_binary_builtin(paadd_i8x8, int8x8_t, __builtin_riscv_paadd_i8x8)
__packed_binary_builtin(paadd_i16x4, int16x4_t, __builtin_riscv_paadd_i16x4)
__packed_binary_builtin(paadd_i32x2, int32x2_t, __builtin_riscv_paadd_i32x2)
__packed_binary_builtin(paaddu_u8x8, uint8x8_t, __builtin_riscv_paaddu_u8x8)
__packed_binary_builtin(paaddu_u16x4, uint16x4_t, __builtin_riscv_paaddu_u16x4)
__packed_binary_builtin(paaddu_u32x2, uint32x2_t, __builtin_riscv_paaddu_u32x2)
__packed_binary_builtin(pasub_i8x8, int8x8_t, __builtin_riscv_pasub_i8x8)
__packed_binary_builtin(pasub_i16x4, int16x4_t, __builtin_riscv_pasub_i16x4)
__packed_binary_builtin(pasub_i32x2, int32x2_t, __builtin_riscv_pasub_i32x2)
__packed_binary_builtin(pasubu_u8x8, uint8x8_t, __builtin_riscv_pasubu_u8x8)
__packed_binary_builtin(pasubu_u16x4, uint16x4_t, __builtin_riscv_pasubu_u16x4)
__packed_binary_builtin(pasubu_u32x2, uint32x2_t, __builtin_riscv_pasubu_u32x2)

/* Packed Absolute Value and Absolute Difference (32-bit) */
__packed_pabs(pabs_i8x4, int8x4_t, uint8x4_t)
__packed_pabs(pabs_i16x2, int16x2_t, uint16x2_t)
__packed_binary_builtin_cast(pabd_i8x4, int8x4_t, uint8x4_t, __builtin_riscv_pabd_i8x4)
__packed_binary_builtin_cast(pabd_i16x2, int16x2_t, uint16x2_t, __builtin_riscv_pabd_i16x2)
__packed_binary_builtin_cast(pabdu_u8x4, uint8x4_t, uint8x4_t, __builtin_riscv_pabdu_u8x4)
__packed_binary_builtin_cast(pabdu_u16x2, uint16x2_t, uint16x2_t, __builtin_riscv_pabdu_u16x2)

/* Packed Absolute Value and Absolute Difference (64-bit) */
__packed_pabs(pabs_i8x8, int8x8_t, uint8x8_t)
__packed_pabs(pabs_i16x4, int16x4_t, uint16x4_t)
__packed_binary_builtin_cast(pabd_i8x8, int8x8_t, uint8x8_t, __builtin_riscv_pabd_i8x8)
__packed_binary_builtin_cast(pabd_i16x4, int16x4_t, uint16x4_t, __builtin_riscv_pabd_i16x4)
__packed_binary_builtin_cast(pabdu_u8x8, uint8x8_t, uint8x8_t, __builtin_riscv_pabdu_u8x8)
__packed_binary_builtin_cast(pabdu_u16x4, uint16x4_t, uint16x4_t, __builtin_riscv_pabdu_u16x4)

/* Packed Reduction Sum (32-bit) */
__packed_reduction(predsum_i8x4_i32, int32_t, int8x4_t, __builtin_riscv_predsum_i8x4_i32)
__packed_reduction(predsumu_u8x4_u32, uint32_t, uint8x4_t, __builtin_riscv_predsumu_u8x4_u32)
__packed_reduction(predsum_i16x2_i32, int32_t, int16x2_t, __builtin_riscv_predsum_i16x2_i32)
__packed_reduction(predsumu_u16x2_u32, uint32_t, uint16x2_t, __builtin_riscv_predsumu_u16x2_u32)

/* Packed Reduction Sum (64-bit) */
__packed_reduction(predsum_i8x8_i32, int32_t, int8x8_t, __builtin_riscv_predsum_i8x8_i32)
__packed_reduction(predsumu_u8x8_u32, uint32_t, uint8x8_t, __builtin_riscv_predsumu_u8x8_u32)
__packed_reduction(predsum_i16x4_i32, int32_t, int16x4_t, __builtin_riscv_predsum_i16x4_i32)
__packed_reduction(predsumu_u16x4_u32, uint32_t, uint16x4_t, __builtin_riscv_predsumu_u16x4_u32)
__packed_reduction(predsum_i8x8_i64, int64_t, int8x8_t, __builtin_riscv_predsum_i8x8_i64)
__packed_reduction(predsumu_u8x8_u64, uint64_t, uint8x8_t, __builtin_riscv_predsumu_u8x8_u64)
__packed_reduction(predsum_i16x4_i64, int64_t, int16x4_t, __builtin_riscv_predsum_i16x4_i64)
__packed_reduction(predsumu_u16x4_u64, uint64_t, uint16x4_t, __builtin_riscv_predsumu_u16x4_u64)
__packed_reduction(predsum_i32x2_i64, int64_t, int32x2_t, __builtin_riscv_predsum_i32x2_i64)
__packed_reduction(predsumu_u32x2_u64, uint64_t, uint32x2_t, __builtin_riscv_predsumu_u32x2_u64)

/* Packed Merge (32-bit) */
__packed_merge_builtin(pmerge_u8x4, uint8x4_t, uint8x4_t, __builtin_riscv_pmerge_u8x4)
__packed_merge_builtin(pmerge_i8x4, int8x4_t, uint8x4_t, __builtin_riscv_pmerge_i8x4)
__packed_merge_builtin(pmerge_u16x2, uint16x2_t, uint16x2_t, __builtin_riscv_pmerge_u16x2)
__packed_merge_builtin(pmerge_i16x2, int16x2_t, uint16x2_t, __builtin_riscv_pmerge_i16x2)

/* Packed Merge (64-bit) */
__packed_merge_builtin(pmerge_u8x8, uint8x8_t, uint8x8_t, __builtin_riscv_pmerge_u8x8)
__packed_merge_builtin(pmerge_i8x8, int8x8_t, uint8x8_t, __builtin_riscv_pmerge_i8x8)
__packed_merge_builtin(pmerge_u16x4, uint16x4_t, uint16x4_t, __builtin_riscv_pmerge_u16x4)
__packed_merge_builtin(pmerge_i16x4, int16x4_t, uint16x4_t, __builtin_riscv_pmerge_i16x4)
__packed_merge_builtin(pmerge_u32x2, uint32x2_t, uint32x2_t, __builtin_riscv_pmerge_u32x2)
__packed_merge_builtin(pmerge_i32x2, int32x2_t, uint32x2_t, __builtin_riscv_pmerge_i32x2)

/* Packed Multiply High (32-bit) */
__packed_binary_builtin(pmulh_i16x2, int16x2_t, __builtin_riscv_pmulh_i16x2)
__packed_binary_builtin(pmulhr_i16x2, int16x2_t, __builtin_riscv_pmulhr_i16x2)
__packed_binary_builtin(pmulhu_u16x2, uint16x2_t, __builtin_riscv_pmulhu_u16x2)
__packed_binary_builtin(pmulhru_u16x2, uint16x2_t, __builtin_riscv_pmulhru_u16x2)
__packed_binary_builtin_mixed(pmulhsu_i16x2, int16x2_t, int16x2_t, uint16x2_t, __builtin_riscv_pmulhsu_i16x2)
__packed_binary_builtin_mixed(pmulhrsu_i16x2, int16x2_t, int16x2_t, uint16x2_t, __builtin_riscv_pmulhrsu_i16x2)

/* Packed Multiply High Accumulate (32-bit) */
__packed_ternary_builtin(pmhacc_i16x2, int16x2_t, __builtin_riscv_pmhacc_i16x2)
__packed_ternary_builtin(pmhracc_i16x2, int16x2_t, __builtin_riscv_pmhracc_i16x2)
__packed_ternary_builtin(pmhaccu_u16x2, uint16x2_t, __builtin_riscv_pmhaccu_u16x2)
__packed_ternary_builtin(pmhraccu_u16x2, uint16x2_t, __builtin_riscv_pmhraccu_u16x2)
__packed_ternary_builtin_mixed(pmhaccsu_i16x2, int16x2_t, int16x2_t, uint16x2_t, __builtin_riscv_pmhaccsu_i16x2)
__packed_ternary_builtin_mixed(pmhraccsu_i16x2, int16x2_t, int16x2_t, uint16x2_t, __builtin_riscv_pmhraccsu_i16x2)

/* Packed Multiply High (64-bit) */
__packed_binary_builtin(pmulh_i16x4, int16x4_t, __builtin_riscv_pmulh_i16x4)
__packed_binary_builtin(pmulh_i32x2, int32x2_t, __builtin_riscv_pmulh_i32x2)
__packed_binary_builtin(pmulhr_i16x4, int16x4_t, __builtin_riscv_pmulhr_i16x4)
__packed_binary_builtin(pmulhr_i32x2, int32x2_t, __builtin_riscv_pmulhr_i32x2)
__packed_binary_builtin(pmulhu_u16x4, uint16x4_t, __builtin_riscv_pmulhu_u16x4)
__packed_binary_builtin(pmulhu_u32x2, uint32x2_t, __builtin_riscv_pmulhu_u32x2)
__packed_binary_builtin(pmulhru_u16x4, uint16x4_t, __builtin_riscv_pmulhru_u16x4)
__packed_binary_builtin(pmulhru_u32x2, uint32x2_t, __builtin_riscv_pmulhru_u32x2)
__packed_binary_builtin_mixed(pmulhsu_i16x4, int16x4_t, int16x4_t, uint16x4_t, __builtin_riscv_pmulhsu_i16x4)
__packed_binary_builtin_mixed(pmulhsu_i32x2, int32x2_t, int32x2_t, uint32x2_t, __builtin_riscv_pmulhsu_i32x2)
__packed_binary_builtin_mixed(pmulhrsu_i16x4, int16x4_t, int16x4_t, uint16x4_t, __builtin_riscv_pmulhrsu_i16x4)
__packed_binary_builtin_mixed(pmulhrsu_i32x2, int32x2_t, int32x2_t, uint32x2_t, __builtin_riscv_pmulhrsu_i32x2)

/* Packed Multiply High Accumulate (64-bit) */
__packed_ternary_builtin(pmhacc_i16x4, int16x4_t, __builtin_riscv_pmhacc_i16x4)
__packed_ternary_builtin(pmhacc_i32x2, int32x2_t, __builtin_riscv_pmhacc_i32x2)
__packed_ternary_builtin(pmhracc_i16x4, int16x4_t, __builtin_riscv_pmhracc_i16x4)
__packed_ternary_builtin(pmhracc_i32x2, int32x2_t, __builtin_riscv_pmhracc_i32x2)
__packed_ternary_builtin(pmhaccu_u16x4, uint16x4_t, __builtin_riscv_pmhaccu_u16x4)
__packed_ternary_builtin(pmhaccu_u32x2, uint32x2_t, __builtin_riscv_pmhaccu_u32x2)
__packed_ternary_builtin(pmhraccu_u16x4, uint16x4_t, __builtin_riscv_pmhraccu_u16x4)
__packed_ternary_builtin(pmhraccu_u32x2, uint32x2_t, __builtin_riscv_pmhraccu_u32x2)
__packed_ternary_builtin_mixed(pmhaccsu_i16x4, int16x4_t, int16x4_t, uint16x4_t, __builtin_riscv_pmhaccsu_i16x4)
__packed_ternary_builtin_mixed(pmhaccsu_i32x2, int32x2_t, int32x2_t, uint32x2_t, __builtin_riscv_pmhaccsu_i32x2)
__packed_ternary_builtin_mixed(pmhraccsu_i16x4, int16x4_t, int16x4_t, uint16x4_t, __builtin_riscv_pmhraccsu_i16x4)
__packed_ternary_builtin_mixed(pmhraccsu_i32x2, int32x2_t, int32x2_t, uint32x2_t, __builtin_riscv_pmhraccsu_i32x2)

/* Packed Multiplication with Horizontal Addition (32-bit) */
__packed_binary_builtin_mixed(pm4add_i8x4, int32_t, int8x4_t, int8x4_t, __builtin_riscv_pm4add_i8x4)
__packed_binary_builtin_mixed(pm2add_i16x2, int32_t, int16x2_t, int16x2_t, __builtin_riscv_pm2add_i16x2)
__packed_binary_builtin_mixed(pm2add_x_i16x2, int32_t, int16x2_t, int16x2_t, __builtin_riscv_pm2add_x_i16x2)
__packed_binary_builtin_mixed(pm4addu_u8x4, uint32_t, uint8x4_t, uint8x4_t, __builtin_riscv_pm4addu_u8x4)
__packed_binary_builtin_mixed(pm2addu_u16x2, uint32_t, uint16x2_t, uint16x2_t, __builtin_riscv_pm2addu_u16x2)
__packed_binary_builtin_mixed(pmq2add_i16x2, int32_t, int16x2_t, int16x2_t, __builtin_riscv_pmq2add_i16x2)
__packed_binary_builtin_mixed(pmqr2add_i16x2, int32_t, int16x2_t, int16x2_t, __builtin_riscv_pmqr2add_i16x2)
__packed_binary_builtin_mixed(pm2sadd_i16x2, int32_t, int16x2_t, int16x2_t, __builtin_riscv_pm2sadd_i16x2)
__packed_binary_builtin_mixed(pm2sadd_x_i16x2, int32_t, int16x2_t, int16x2_t, __builtin_riscv_pm2sadd_x_i16x2)
__packed_binary_builtin_mixed(pm2sub_i16x2, int32_t, int16x2_t, int16x2_t, __builtin_riscv_pm2sub_i16x2)
__packed_binary_builtin_mixed(pm2sub_x_i16x2, int32_t, int16x2_t, int16x2_t, __builtin_riscv_pm2sub_x_i16x2)
__packed_binary_builtin_mixed(pm4addsu_i8x4, int32_t, int8x4_t, uint8x4_t, __builtin_riscv_pm4addsu_i8x4)
__packed_binary_builtin_mixed(pm2addsu_i16x2, int32_t, int16x2_t, uint16x2_t, __builtin_riscv_pm2addsu_i16x2)

/* Packed Multiplication with Horizontal Addition (64-bit) */
__packed_binary_builtin_mixed(pm4add_i8x8, int32x2_t, int8x8_t, int8x8_t, __builtin_riscv_pm4add_i8x8)
__packed_binary_builtin_mixed(pm2add_i16x4, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pm2add_i16x4)
__packed_binary_builtin_mixed(pm2add_x_i16x4, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pm2add_x_i16x4)
__packed_binary_builtin_mixed(pm4addu_u8x8, uint32x2_t, uint8x8_t, uint8x8_t, __builtin_riscv_pm4addu_u8x8)
__packed_binary_builtin_mixed(pm2addu_u16x4, uint32x2_t, uint16x4_t, uint16x4_t, __builtin_riscv_pm2addu_u16x4)
__packed_binary_builtin_mixed(pmq2add_i16x4, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pmq2add_i16x4)
__packed_binary_builtin_mixed(pmqr2add_i16x4, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pmqr2add_i16x4)
__packed_binary_builtin_mixed(pm2sadd_i16x4, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pm2sadd_i16x4)
__packed_binary_builtin_mixed(pm2sadd_x_i16x4, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pm2sadd_x_i16x4)
__packed_binary_builtin_mixed(pm2sub_i16x4, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pm2sub_i16x4)
__packed_binary_builtin_mixed(pm2sub_x_i16x4, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pm2sub_x_i16x4)
__packed_binary_builtin_mixed(pm4addsu_i8x8, int32x2_t, int8x8_t, uint8x8_t, __builtin_riscv_pm4addsu_i8x8)
__packed_binary_builtin_mixed(pm2addsu_i16x4, int32x2_t, int16x4_t, uint16x4_t, __builtin_riscv_pm2addsu_i16x4)
__packed_binary_builtin_mixed(pm2add_i32x2, int64_t, int32x2_t, int32x2_t, __builtin_riscv_pm2add_i32x2)
__packed_binary_builtin_mixed(pm2add_x_i32x2, int64_t, int32x2_t, int32x2_t, __builtin_riscv_pm2add_x_i32x2)
__packed_binary_builtin_mixed(pm2addu_u32x2, uint64_t, uint32x2_t, uint32x2_t, __builtin_riscv_pm2addu_u32x2)
__packed_binary_builtin_mixed(pmq2add_i32x2, int64_t, int32x2_t, int32x2_t, __builtin_riscv_pmq2add_i32x2)
__packed_binary_builtin_mixed(pm2sub_i32x2, int64_t, int32x2_t, int32x2_t, __builtin_riscv_pm2sub_i32x2)
__packed_binary_builtin_mixed(pm2sub_x_i32x2, int64_t, int32x2_t, int32x2_t, __builtin_riscv_pm2sub_x_i32x2)
__packed_binary_builtin_mixed(pm2addsu_i32x2, int64_t, int32x2_t, uint32x2_t, __builtin_riscv_pm2addsu_i32x2)
__packed_binary_builtin_mixed(pmqr2add_i32x2, int64_t, int32x2_t, int32x2_t, __builtin_riscv_pmqr2add_i32x2)
__packed_binary_builtin_mixed(pm4add_i16x4, int64_t, int16x4_t, int16x4_t, __builtin_riscv_pm4add_i16x4)
__packed_binary_builtin_mixed(pm4addu_u16x4, uint64_t, uint16x4_t, uint16x4_t, __builtin_riscv_pm4addu_u16x4)
__packed_binary_builtin_mixed(pm4addsu_i16x4, int64_t, int16x4_t, uint16x4_t, __builtin_riscv_pm4addsu_i16x4)

/* Packed Absolute Difference Sum (32-bit) */
__packed_abdsum(pabdsumu_u8x4_u32, uint32_t, uint8x4_t, __builtin_riscv_pabdsumu_u8x4_u32)
__packed_ternary_builtin_cast(pabdsumau_u8x4_u32, uint32_t, uint8x4_t, __builtin_riscv_pabdsumau_u8x4_u32)

/* Packed Absolute Difference Sum (64-bit) */
__packed_abdsum(pabdsumu_u8x8_u32, uint32_t, uint8x8_t, __builtin_riscv_pabdsumu_u8x8_u32)
__packed_abdsum(pabdsumu_u8x8_u64, uint64_t, uint8x8_t, __builtin_riscv_pabdsumu_u8x8_u64)
__packed_ternary_builtin_cast(pabdsumau_u8x8_u32, uint32_t, uint8x8_t, __builtin_riscv_pabdsumau_u8x8_u32)
__packed_ternary_builtin_cast(pabdsumau_u8x8_u64, uint64_t, uint8x8_t, __builtin_riscv_pabdsumau_u8x8_u64)

/* Packed Saturating Absolute Value (32-bit) */
__packed_unary_builtin(psabs_i8x4, int8x4_t, __builtin_riscv_psabs_i8x4)
__packed_unary_builtin(psabs_i16x2, int16x2_t, __builtin_riscv_psabs_i16x2)

/* Packed Saturating Absolute Value (64-bit) */
__packed_unary_builtin(psabs_i8x8, int8x8_t, __builtin_riscv_psabs_i8x8)
__packed_unary_builtin(psabs_i16x4, int16x4_t, __builtin_riscv_psabs_i16x4)

/* Packed Sign and Zero Extend (32-bit) */
__packed_unary_builtin(psext_b_i16x2, int16x2_t, __builtin_riscv_psext_b_i16x2)
__packed_unary_builtin(pzext_b_u16x2, uint16x2_t, __builtin_riscv_pzext_b_u16x2)

/* Packed Sign and Zero Extend (64-bit) */
__packed_unary_builtin(psext_b_i16x4, int16x4_t, __builtin_riscv_psext_b_i16x4)
__packed_unary_builtin(psext_b_i32x2, int32x2_t, __builtin_riscv_psext_b_i32x2)
__packed_unary_builtin(psext_h_i32x2, int32x2_t, __builtin_riscv_psext_h_i32x2)
__packed_unary_builtin(pzext_b_u16x4, uint16x4_t, __builtin_riscv_pzext_b_u16x4)
__packed_unary_builtin(pzext_h_u32x2, uint32x2_t, __builtin_riscv_pzext_h_u32x2)

/* Packed "Q-format" Multiplication (32-bit) */
__packed_binary_builtin(pmulq_i16x2, int16x2_t, __builtin_riscv_pmulq_i16x2)
__packed_binary_builtin(pmulqr_i16x2, int16x2_t, __builtin_riscv_pmulqr_i16x2)

/* Packed "Q-format" Multiplication (64-bit) */
__packed_binary_builtin(pmulq_i16x4, int16x4_t, __builtin_riscv_pmulq_i16x4)
__packed_binary_builtin(pmulqr_i16x4, int16x4_t, __builtin_riscv_pmulqr_i16x4)
__packed_binary_builtin(pmulq_i32x2, int32x2_t, __builtin_riscv_pmulq_i32x2)
__packed_binary_builtin(pmulqr_i32x2, int32x2_t, __builtin_riscv_pmulqr_i32x2)

/* Packed Multiply Parts (32-bit) */
__packed_binary_builtin_mixed(pmul_b00_i16x2, int16x2_t, int8x4_t, int8x4_t, __builtin_riscv_pmul_b00_i16x2)
__packed_binary_builtin_mixed(pmul_b01_i16x2, int16x2_t, int8x4_t, int8x4_t, __builtin_riscv_pmul_b01_i16x2)
__packed_binary_builtin_mixed(pmul_b11_i16x2, int16x2_t, int8x4_t, int8x4_t, __builtin_riscv_pmul_b11_i16x2)
__packed_binary_builtin_mixed(pmulu_b00_u16x2, uint16x2_t, uint8x4_t, uint8x4_t, __builtin_riscv_pmulu_b00_u16x2)
__packed_binary_builtin_mixed(pmulu_b01_u16x2, uint16x2_t, uint8x4_t, uint8x4_t, __builtin_riscv_pmulu_b01_u16x2)
__packed_binary_builtin_mixed(pmulu_b11_u16x2, uint16x2_t, uint8x4_t, uint8x4_t, __builtin_riscv_pmulu_b11_u16x2)
__packed_binary_builtin_mixed(pmulsu_b00_i16x2, int16x2_t, int8x4_t, uint8x4_t, __builtin_riscv_pmulsu_b00_i16x2)
__packed_binary_builtin_mixed(pmulsu_b11_i16x2, int16x2_t, int8x4_t, uint8x4_t, __builtin_riscv_pmulsu_b11_i16x2)
__packed_binary_builtin_mixed(mul_h00_i32, int32_t, int16x2_t, int16x2_t, __builtin_riscv_mul_h00_i32)
__packed_binary_builtin_mixed(mul_h01_i32, int32_t, int16x2_t, int16x2_t, __builtin_riscv_mul_h01_i32)
__packed_binary_builtin_mixed(mul_h11_i32, int32_t, int16x2_t, int16x2_t, __builtin_riscv_mul_h11_i32)
__packed_binary_builtin_mixed(mulu_h00_u32, uint32_t, uint16x2_t, uint16x2_t, __builtin_riscv_mulu_h00_u32)
__packed_binary_builtin_mixed(mulu_h01_u32, uint32_t, uint16x2_t, uint16x2_t, __builtin_riscv_mulu_h01_u32)
__packed_binary_builtin_mixed(mulu_h11_u32, uint32_t, uint16x2_t, uint16x2_t, __builtin_riscv_mulu_h11_u32)
__packed_binary_builtin_mixed(mulsu_h00_i32, int32_t, int16x2_t, uint16x2_t, __builtin_riscv_mulsu_h00_i32)
__packed_binary_builtin_mixed(mulsu_h11_i32, int32_t, int16x2_t, uint16x2_t, __builtin_riscv_mulsu_h11_i32)

/* Packed Multiply Parts (64-bit) */
__packed_binary_builtin_mixed(pmul_b00_i16x4, int16x4_t, int8x8_t, int8x8_t, __builtin_riscv_pmul_b00_i16x4)
__packed_binary_builtin_mixed(pmul_b01_i16x4, int16x4_t, int8x8_t, int8x8_t, __builtin_riscv_pmul_b01_i16x4)
__packed_binary_builtin_mixed(pmul_b11_i16x4, int16x4_t, int8x8_t, int8x8_t, __builtin_riscv_pmul_b11_i16x4)
__packed_binary_builtin_mixed(pmulu_b00_u16x4, uint16x4_t, uint8x8_t, uint8x8_t, __builtin_riscv_pmulu_b00_u16x4)
__packed_binary_builtin_mixed(pmulu_b01_u16x4, uint16x4_t, uint8x8_t, uint8x8_t, __builtin_riscv_pmulu_b01_u16x4)
__packed_binary_builtin_mixed(pmulu_b11_u16x4, uint16x4_t, uint8x8_t, uint8x8_t, __builtin_riscv_pmulu_b11_u16x4)
__packed_binary_builtin_mixed(pmulsu_b00_i16x4, int16x4_t, int8x8_t, uint8x8_t, __builtin_riscv_pmulsu_b00_i16x4)
__packed_binary_builtin_mixed(pmulsu_b11_i16x4, int16x4_t, int8x8_t, uint8x8_t, __builtin_riscv_pmulsu_b11_i16x4)
__packed_binary_builtin_mixed(pmul_h00_i32x2, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pmul_h00_i32x2)
__packed_binary_builtin_mixed(pmul_h01_i32x2, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pmul_h01_i32x2)
__packed_binary_builtin_mixed(pmul_h11_i32x2, int32x2_t, int16x4_t, int16x4_t, __builtin_riscv_pmul_h11_i32x2)
__packed_binary_builtin_mixed(pmulu_h00_u32x2, uint32x2_t, uint16x4_t, uint16x4_t, __builtin_riscv_pmulu_h00_u32x2)
__packed_binary_builtin_mixed(pmulu_h01_u32x2, uint32x2_t, uint16x4_t, uint16x4_t, __builtin_riscv_pmulu_h01_u32x2)
__packed_binary_builtin_mixed(pmulu_h11_u32x2, uint32x2_t, uint16x4_t, uint16x4_t, __builtin_riscv_pmulu_h11_u32x2)
__packed_binary_builtin_mixed(pmulsu_h00_i32x2, int32x2_t, int16x4_t, uint16x4_t, __builtin_riscv_pmulsu_h00_i32x2)
__packed_binary_builtin_mixed(pmulsu_h11_i32x2, int32x2_t, int16x4_t, uint16x4_t, __builtin_riscv_pmulsu_h11_i32x2)
__packed_binary_builtin_mixed(mul_w00_i64, int64_t, int32x2_t, int32x2_t, __builtin_riscv_mul_w00_i64)
__packed_binary_builtin_mixed(mul_w01_i64, int64_t, int32x2_t, int32x2_t, __builtin_riscv_mul_w01_i64)
__packed_binary_builtin_mixed(mul_w11_i64, int64_t, int32x2_t, int32x2_t, __builtin_riscv_mul_w11_i64)
__packed_binary_builtin_mixed(mulu_w00_u64, uint64_t, uint32x2_t, uint32x2_t, __builtin_riscv_mulu_w00_u64)
__packed_binary_builtin_mixed(mulu_w01_u64, uint64_t, uint32x2_t, uint32x2_t, __builtin_riscv_mulu_w01_u64)
__packed_binary_builtin_mixed(mulu_w11_u64, uint64_t, uint32x2_t, uint32x2_t, __builtin_riscv_mulu_w11_u64)
__packed_binary_builtin_mixed(mulsu_w00_i64, int64_t, int32x2_t, uint32x2_t, __builtin_riscv_mulsu_w00_i64)
__packed_binary_builtin_mixed(mulsu_w11_i64, int64_t, int32x2_t, uint32x2_t, __builtin_riscv_mulsu_w11_i64)

/* Packed "Q-format" Multiply Parts Accumulate (32-bit) */
__packed_ternary_builtin_cast(mqacc_h00_i32, int, int16x2_t, __builtin_riscv_mqacc_h00_i32)
__packed_ternary_builtin_cast(mqacc_h01_i32, int, int16x2_t, __builtin_riscv_mqacc_h01_i32)
__packed_ternary_builtin_cast(mqacc_h11_i32, int, int16x2_t, __builtin_riscv_mqacc_h11_i32)
__packed_ternary_builtin_cast(mqracc_h00_i32, int, int16x2_t, __builtin_riscv_mqracc_h00_i32)
__packed_ternary_builtin_cast(mqracc_h01_i32, int, int16x2_t, __builtin_riscv_mqracc_h01_i32)
__packed_ternary_builtin_cast(mqracc_h11_i32, int, int16x2_t, __builtin_riscv_mqracc_h11_i32)

/* Packed "Q-format" Multiply Parts Accumulate (64-bit) */
__packed_ternary_builtin_cast(pmqacc_h00_i32x2, int32x2_t, int16x4_t, __builtin_riscv_pmqacc_h00_i32x2)
__packed_ternary_builtin_cast(pmqacc_h01_i32x2, int32x2_t, int16x4_t, __builtin_riscv_pmqacc_h01_i32x2)
__packed_ternary_builtin_cast(pmqacc_h11_i32x2, int32x2_t, int16x4_t, __builtin_riscv_pmqacc_h11_i32x2)
__packed_ternary_builtin_cast(pmqracc_h00_i32x2, int32x2_t, int16x4_t, __builtin_riscv_pmqracc_h00_i32x2)
__packed_ternary_builtin_cast(pmqracc_h01_i32x2, int32x2_t, int16x4_t, __builtin_riscv_pmqracc_h01_i32x2)
__packed_ternary_builtin_cast(pmqracc_h11_i32x2, int32x2_t, int16x4_t, __builtin_riscv_pmqracc_h11_i32x2)
__packed_ternary_builtin_cast(mqacc_w00_i64, int64_t, int32x2_t, __builtin_riscv_mqacc_w00_i64)
__packed_ternary_builtin_cast(mqacc_w01_i64, int64_t, int32x2_t, __builtin_riscv_mqacc_w01_i64)
__packed_ternary_builtin_cast(mqacc_w11_i64, int64_t, int32x2_t, __builtin_riscv_mqacc_w11_i64)
__packed_ternary_builtin_cast(mqracc_w00_i64, int64_t, int32x2_t, __builtin_riscv_mqracc_w00_i64)
__packed_ternary_builtin_cast(mqracc_w01_i64, int64_t, int32x2_t, __builtin_riscv_mqracc_w01_i64)
__packed_ternary_builtin_cast(mqracc_w11_i64, int64_t, int32x2_t, __builtin_riscv_mqracc_w11_i64)

/* Packed Narrowing Clip Pair (32-bit) */
__packed_binary_builtin_cast(pnclipp_i8x4, int16x2_t, int8x4_t, __builtin_riscv_pnclipp_i8x4)
__packed_binary_builtin_cast(pnclipup_u8x4, uint16x2_t, uint8x4_t, __builtin_riscv_pnclipup_u8x4)
__packed_binary_builtin_cast(pnclipp_i16x2, int, int16x2_t, __builtin_riscv_pnclipp_i16x2)
__packed_binary_builtin_cast(pnclipup_u16x2, unsigned int, uint16x2_t, __builtin_riscv_pnclipup_u16x2)

/* Packed Narrowing Clip Pair (64-bit) */
__packed_binary_builtin_cast(pnclipp_i8x8, int16x4_t, int8x8_t, __builtin_riscv_pnclipp_i8x8)
__packed_binary_builtin_cast(pnclipup_u8x8, uint16x4_t, uint8x8_t, __builtin_riscv_pnclipup_u8x8)
__packed_binary_builtin_cast(pnclipp_i16x4, int32x2_t, int16x4_t, __builtin_riscv_pnclipp_i16x4)
__packed_binary_builtin_cast(pnclipup_u16x4, uint32x2_t, uint16x4_t, __builtin_riscv_pnclipup_u16x4)
__packed_binary_builtin_cast(pnclipp_i32x2, int64_t, int32x2_t, __builtin_riscv_pnclipp_i32x2)
__packed_binary_builtin_cast(pnclipup_u32x2, uint64_t, uint32x2_t, __builtin_riscv_pnclipup_u32x2)

/* Reinterpret Casts, Packed <-> Scalar (32-bit) */
__packed_reinterpret(u8x4_u32, uint32_t, uint8x4_t)
__packed_reinterpret(u16x2_u32, uint32_t, uint16x2_t)
__packed_reinterpret(i8x4_u32, uint32_t, int8x4_t)
__packed_reinterpret(i16x2_u32, uint32_t, int16x2_t)
__packed_reinterpret(u8x4_i32, int32_t, uint8x4_t)
__packed_reinterpret(u16x2_i32, int32_t, uint16x2_t)
__packed_reinterpret(i8x4_i32, int32_t, int8x4_t)
__packed_reinterpret(i16x2_i32, int32_t, int16x2_t)
__packed_reinterpret(u32_u8x4, uint8x4_t, uint32_t)
__packed_reinterpret(u32_u16x2, uint16x2_t, uint32_t)
__packed_reinterpret(u32_i8x4, int8x4_t, uint32_t)
__packed_reinterpret(u32_i16x2, int16x2_t, uint32_t)
__packed_reinterpret(i32_u8x4, uint8x4_t, int32_t)
__packed_reinterpret(i32_u16x2, uint16x2_t, int32_t)
__packed_reinterpret(i32_i8x4, int8x4_t, int32_t)
__packed_reinterpret(i32_i16x2, int16x2_t, int32_t)

/* Reinterpret Casts, Packed <-> Scalar (64-bit) */
__packed_reinterpret(u8x8_u64, uint64_t, uint8x8_t)
__packed_reinterpret(u16x4_u64, uint64_t, uint16x4_t)
__packed_reinterpret(u32x2_u64, uint64_t, uint32x2_t)
__packed_reinterpret(i8x8_u64, uint64_t, int8x8_t)
__packed_reinterpret(i16x4_u64, uint64_t, int16x4_t)
__packed_reinterpret(i32x2_u64, uint64_t, int32x2_t)
__packed_reinterpret(u8x8_i64, int64_t, uint8x8_t)
__packed_reinterpret(u16x4_i64, int64_t, uint16x4_t)
__packed_reinterpret(u32x2_i64, int64_t, uint32x2_t)
__packed_reinterpret(i8x8_i64, int64_t, int8x8_t)
__packed_reinterpret(i16x4_i64, int64_t, int16x4_t)
__packed_reinterpret(i32x2_i64, int64_t, int32x2_t)
__packed_reinterpret(u64_u8x8, uint8x8_t, uint64_t)
__packed_reinterpret(u64_u16x4, uint16x4_t, uint64_t)
__packed_reinterpret(u64_u32x2, uint32x2_t, uint64_t)
__packed_reinterpret(u64_i8x8, int8x8_t, uint64_t)
__packed_reinterpret(u64_i16x4, int16x4_t, uint64_t)
__packed_reinterpret(u64_i32x2, int32x2_t, uint64_t)
__packed_reinterpret(i64_u8x8, uint8x8_t, int64_t)
__packed_reinterpret(i64_u16x4, uint16x4_t, int64_t)
__packed_reinterpret(i64_u32x2, uint32x2_t, int64_t)
__packed_reinterpret(i64_i8x8, int8x8_t, int64_t)
__packed_reinterpret(i64_i16x4, int16x4_t, int64_t)
__packed_reinterpret(i64_i32x2, int32x2_t, int64_t)

/* Reinterpret Casts, Packed <-> Packed (32-bit) */
__packed_reinterpret(i8x4_u8x4, uint8x4_t, int8x4_t)
__packed_reinterpret(u16x2_u8x4, uint8x4_t, uint16x2_t)
__packed_reinterpret(i16x2_u8x4, uint8x4_t, int16x2_t)
__packed_reinterpret(u8x4_i8x4, int8x4_t, uint8x4_t)
__packed_reinterpret(u16x2_i8x4, int8x4_t, uint16x2_t)
__packed_reinterpret(i16x2_i8x4, int8x4_t, int16x2_t)
__packed_reinterpret(u8x4_u16x2, uint16x2_t, uint8x4_t)
__packed_reinterpret(i8x4_u16x2, uint16x2_t, int8x4_t)
__packed_reinterpret(i16x2_u16x2, uint16x2_t, int16x2_t)
__packed_reinterpret(u8x4_i16x2, int16x2_t, uint8x4_t)
__packed_reinterpret(i8x4_i16x2, int16x2_t, int8x4_t)
__packed_reinterpret(u16x2_i16x2, int16x2_t, uint16x2_t)

/* Reinterpret Casts, Packed <-> Packed (64-bit) */
__packed_reinterpret(i8x8_u8x8, uint8x8_t, int8x8_t)
__packed_reinterpret(u16x4_u8x8, uint8x8_t, uint16x4_t)
__packed_reinterpret(i16x4_u8x8, uint8x8_t, int16x4_t)
__packed_reinterpret(u32x2_u8x8, uint8x8_t, uint32x2_t)
__packed_reinterpret(i32x2_u8x8, uint8x8_t, int32x2_t)
__packed_reinterpret(u8x8_i8x8, int8x8_t, uint8x8_t)
__packed_reinterpret(u16x4_i8x8, int8x8_t, uint16x4_t)
__packed_reinterpret(i16x4_i8x8, int8x8_t, int16x4_t)
__packed_reinterpret(u32x2_i8x8, int8x8_t, uint32x2_t)
__packed_reinterpret(i32x2_i8x8, int8x8_t, int32x2_t)
__packed_reinterpret(u8x8_u16x4, uint16x4_t, uint8x8_t)
__packed_reinterpret(i8x8_u16x4, uint16x4_t, int8x8_t)
__packed_reinterpret(i16x4_u16x4, uint16x4_t, int16x4_t)
__packed_reinterpret(u32x2_u16x4, uint16x4_t, uint32x2_t)
__packed_reinterpret(i32x2_u16x4, uint16x4_t, int32x2_t)
__packed_reinterpret(u8x8_i16x4, int16x4_t, uint8x8_t)
__packed_reinterpret(i8x8_i16x4, int16x4_t, int8x8_t)
__packed_reinterpret(u16x4_i16x4, int16x4_t, uint16x4_t)
__packed_reinterpret(u32x2_i16x4, int16x4_t, uint32x2_t)
__packed_reinterpret(i32x2_i16x4, int16x4_t, int32x2_t)
__packed_reinterpret(u8x8_u32x2, uint32x2_t, uint8x8_t)
__packed_reinterpret(i8x8_u32x2, uint32x2_t, int8x8_t)
__packed_reinterpret(u16x4_u32x2, uint32x2_t, uint16x4_t)
__packed_reinterpret(i16x4_u32x2, uint32x2_t, int16x4_t)
__packed_reinterpret(i32x2_u32x2, uint32x2_t, int32x2_t)
__packed_reinterpret(u8x8_i32x2, int32x2_t, uint8x8_t)
__packed_reinterpret(i8x8_i32x2, int32x2_t, int8x8_t)
__packed_reinterpret(u16x4_i32x2, int32x2_t, uint16x4_t)
__packed_reinterpret(i16x4_i32x2, int32x2_t, int16x4_t)
__packed_reinterpret(u32x2_i32x2, int32x2_t, uint32x2_t)

// clang-format on

#undef __packed_splat2
#undef __packed_splat4
#undef __packed_splat8
#undef __packed_splat
#undef __packed_shift
#undef __packed_shift8
#undef __packed_shift16
#undef __packed_shift32
#undef __packed_scalar_binary_op
#undef __packed_binary_op
#undef __packed_unary_op
#undef __packed_binary_builtin
#undef __packed_binary_builtin_mixed
#undef __packed_ternary_builtin
#undef __packed_ternary_builtin_mixed
#undef __packed_sh1add
#undef __packed_sh1sadd
#undef __packed_cmp
#undef __packed_pabs
#undef __packed_binary_builtin_cast
#undef __packed_reduction
#undef __packed_merge_builtin
#undef __packed_unary_builtin
#undef __packed_widen_convert
#undef __packed_widen_binary_op
#undef __packed_widen_mul
#undef __packed_widen_mulsu
#undef __packed_widen_high2
#undef __packed_widen_high4
#undef __packed_narrow_even2
#undef __packed_narrow_even4
#undef __packed_narrow_odd2
#undef __packed_narrow_odd4
#undef __packed_reverse2
#undef __packed_reverse4
#undef __packed_reverse8
#undef __packed_zip2
#undef __packed_zip4
#undef __packed_unzipe2
#undef __packed_unzipe4
#undef __packed_unzipo2
#undef __packed_unzipo4
#undef __packed_pair_ee4
#undef __packed_pair_eo4
#undef __packed_pair_oe4
#undef __packed_pair_oo4
#undef __packed_pair_ee8
#undef __packed_pair_eo8
#undef __packed_pair_oe8
#undef __packed_pair_oo8
#undef __packed_nzip2
#undef __packed_nzip4
#undef __packed_nziph2
#undef __packed_nziph4
#undef __packed_abdsum
#undef __packed_ternary_builtin_cast
#undef __packed_reinterpret
#undef __DEFAULT_FN_ATTRS

#if defined(__cplusplus)
}
#endif

#endif /* __RISCV_PACKED_SIMD_H */
